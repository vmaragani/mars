package com.mars.javacode.excercise.com.mars.javacode.excercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaCodeExcerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
