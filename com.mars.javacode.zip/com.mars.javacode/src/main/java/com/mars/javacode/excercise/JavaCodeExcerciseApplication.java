package com.mars.javacode.excercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaCodeExcerciseApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaCodeExcerciseApplication.class, args);
	}

}
